package pitayaa.nail.msg.core.account.controller;

import lombok.Data;

@Data
public class ObjectTest {
	private String username;
	private String password;
}
