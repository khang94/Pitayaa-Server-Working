package pitayaa.nail.msg.core.view.service;

public interface ViewService {

}
