package pitayaa.nail.msg.core.hibernate;

import lombok.Data;

@Data
public class QueryCriteria {
	
	String query;
	String object;
	String description;
}
