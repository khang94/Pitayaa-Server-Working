package pitayaa.nail.msg.core.view.repository;

public interface ViewRepository {

}
