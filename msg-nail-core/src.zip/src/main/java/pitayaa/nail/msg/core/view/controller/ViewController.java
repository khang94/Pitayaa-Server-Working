package pitayaa.nail.msg.core.view.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ViewController {

}
